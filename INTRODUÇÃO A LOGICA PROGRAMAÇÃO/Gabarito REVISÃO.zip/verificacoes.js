// 1 Crie um programa que verifica se um número é par ou ímpar e exiba uma mensagem correspondente

let num = 7;

if (num % 2 === 0) {
  console.log("O número é par!");
} else {
  console.log("O número é ímpar!");
}

// 2 Crie um programa que verifica se uma pessoa é maior de idade (idade igual ou superior a 18 anos) e exiba uma mensagem autorizando ou não a entrar na festa.

let idade = 19;

if (idade >= 18) {
  console.log("Seja bem vindo à festa!");
} else {
  console.log("Você é menor de idade, não pode entrar.");
}

// 3 Crie um programa que verifica se um número é positivo, negativo ou zero, e exiba uma mensagem correspondente.

let numero = 10;

if (numero > 0) {
  console.log("O número é positivo.");
} else if (numero < 0) {
  console.log("O número é negativo.");
} else {
  console.log("O número é zero.");
}

// 4 Crie um programa que recebe os três lados de um triângulo e determina se ele é equilátero (todos os lados iguais), isósceles (dois lados iguais) ou escaleno (todos os lados diferentes).

let lado1 = 4;
let lado2 = 5;
let lado3 = 6;

if (lado1 === lado2 && lado1 === lado3) {
  console.log("É um equilátero");
} else if (lado1 === lado2 || lado1 === lado3 || lado2 === lado3) {
  console.log("É um isósceles");
} else {
  console.log("É um escaleno");
}

// 5 Crie um programa que recebe o preço de um produto e o percentual de desconto a ser aplicado. Se o preço for maior ou igual a R$100 e o desconto for maior ou igual a 10%, o programa deve calcular o preço com o desconto e exibir o resultado. Caso contrário, deve exibir uma mensagem informando que não é possível aplicar o desconto.

let preco = 100;
let percentualDesconto = 10;

if (preco >= 100 && percentualDesconto >= 10) {
  let precoComDesconto = preco - (preco * 10) / 100;
  console.log("O valor com desconto é de :", precoComDesconto);
} else {
  console.log(
    "A compra ou o desconto não atingiram os critérios mínimos para seu desconto."
  );
}

// 6 Crie um programa que verifica se um ano é bissexto. Um ano é bissexto se for divisível por 4, exceto quando é divisível por 100. Porém, é bissexto novamente se for divisível por 400.
let ano = 2024;

if ((ano % 4 === 0 && ano % 100 !== 0) || ano % 400 === 0) {
  console.log("É bissexto");
} else {
  console.log("Não é bissexto");
}

// 7 Informe qual a estação do ano dependendo do mês que o usuário informar.

let mes = "Janeiro";

switch (mes) {
  case "Janeiro":
    console.log("A estação do ano é: Verão");
    break;
  case "Fevereiro":
    console.log("A estação do ano é: Verão");
    break;
  case "Março":
    console.log("A estação do ano é: Outono");
    break;
  case "Abril":
    console.log("A estação do ano é: Outono");
    break;
  case "Maio":
    console.log("A estação do ano é: Outono");
    break;
  case "Junho":
    console.log("A estação do ano é: Inverno");
    break;
  case "Julho":
    console.log("A estação do ano é: Inverno");
    break;
  case "Agosto":
    console.log("A estação do ano é: Inverno");
    break;
  case "Setembro":
    console.log("A estação do ano é: Primavera");
    break;
  case "Outubro":
    console.log("A estação do ano é: Primavera");
    break;
  case "Novembro":
    console.log("A estação do ano é: Primavera");
    break;
  case "Dezembro":
    console.log("A estação do ano é: Verão");
    break;
  default:
    console.log("Informe um mês válido!");
    break;
}
