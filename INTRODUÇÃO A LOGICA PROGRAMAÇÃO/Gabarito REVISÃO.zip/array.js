// Crie um programa que calcula e exibe a soma dos elementos de um array de números.

let array = [1, 1, 1];

for(let i = 0; i <= array.length; i++) {
    var soma = 0;
    soma += i;
}

console.log('A soma dos elementos do array é: ', soma);